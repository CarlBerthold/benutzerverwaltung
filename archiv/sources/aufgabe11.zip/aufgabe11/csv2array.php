<?php

$csvData = <<<csvData
Id;Vorname;Nachname;E-Mail-Adresse;Passwort;Rolle;registriert seit;letzte Änderung 
1;Max;Mustermann;max@example.com;password;admin;2023-01-15 08:30:00;2023-02-20 10:45:00
2;Anna;Schmidt;anna@example.com;pass123;user;2023-02-10 11:20:00;2023-03-05 09:15:00
3;Peter;Müller;peter@example.com;p@ssw0rd;user;2023-03-20 14:50:00;2023-04-18 12:30:00
4;Julia;Wagner;julia@example.com;secure12;inactive;2023-04-05 09:10:00;2023-04-20 16:55:00
5;Thomas;Fischer;thomas@example.com;mypass;admin;2023-05-08 10:25:00;2023-05-25 14:20:00
6;Sarah;Becker;sarah@example.com;123456;user;2023-06-12 13:40:00;2023-06-30 17:10:00
7;Michael;Schulz;michael@example.com;testpass;user;2023-07-15 16:55:00;2023-07-28 10:05:00
8;Laura;Hoffmann;laura@example.com;secret;inactive;2023-08-20 18:20:00;2023-09-05 11:25:00
9;Kevin;Richter;kevin@example.com;abc123;admin;2023-09-25 20:45:00;2023-10-15 13:40:00
10;Maria;Lehmann;maria@example.com;passpass;user;2023-10-30 22:00:00;2023-11-20 15:50:00
csvData;

$users = [];

$lines = explode("\n", $csvData);

foreach ($lines as $index => $user) {
    if($index > 0) {
        $users[] = explode(';', $user);
    }
}

# keys hinzufügen

$keyArray = [
    'id',
    'firstname',
    'lastname',
    'email',
    'password',
    'role',
    'created_at',
    'updated_at',
];

foreach ($users as &$user) {
    # Datentyp von id in int umwandeln
    $user[0] = (int)$user[0];
    $user = array_combine($keyArray, $user);
}

var_export($users);