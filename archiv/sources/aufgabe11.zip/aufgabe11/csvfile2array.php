<?php

$file = 'C:/xampp/htdocs/projekte/benutzerverwaltung/source/users.csv';

$users = [];

if (($handle = fopen($file, "r")) !== FALSE) {
    $i = 0;
    while (($data = fgetcsv($handle, null, ";")) !== FALSE) {
        if ($i > 0) {
            // var_dump($data);
            $users[] = $data;
        }
        $i++;
    }

    fclose($handle);
}

# keys hinzufügen

$keyArray = [
    'id',
    'firstname',
    'lastname',
    'email',
    'password',
    'role',
    'created_at',
    'updated_at',
];

foreach ($users as &$user) {
    # Datentyp von id in int umwandeln
    $user[0] = (int)$user[0];
    $user = array_combine($keyArray, $user);
}

var_export($users);
