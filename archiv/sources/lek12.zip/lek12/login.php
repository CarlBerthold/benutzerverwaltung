<?php

# Refactoring 2 - Optimierung loginNames-Array

$userData = [
    [
        'loginname' => 'oliver.vogt@d-taube.de',
        'password' => 'ganzgeheim', // absolutes no-go - Passwörter dürfen nie nie nie in Klartext verfügbar sein
    ],
    [
        'loginname' => 'hans@wurst.de',
        'password' => 'Pa$$w0rd', // absolutes no-go - Passwörter dürfen nie nie nie in Klartext verfügbar sein
    ],
];

$loginNames = array_column($userData, 'password', 'loginname');

// var_dump($loginNames);

// var_dump(array_search('oliver.vogt@d-taube.de', $loginNames));
// exit;


if ($_POST) {
    if (array_key_exists($_POST['loginname'], $loginNames) && $_POST['password'] === $loginNames[$_POST['loginname']]) {
        // hier Weiterleitung auf die gewünschte Seite
        echo "Hallo {$_POST['loginname']} ! Du bist eingelogged";
        header('Location: checkbox_hack.html');
        exit;
    }

    $message = 'Die Kombination Benutzername und Kennwort stimmen nicht überein!';
}

?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>

<body>
    <form action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
        <div>
            <label for="loginname">Loginname: </label>
            <!-- <input type="text" name="loginname" id="loginname" placeholder="Bitte den Loginnamen eingeben" value="<?= (isset($_POST['loginname'])) ? $_POST['loginname'] : '' ?>" required> -->
            <input type="text" name="loginname" id="loginname" placeholder="Bitte den Loginnamen eingeben" value="<?= $_POST['loginname'] ?? '' ?>" required>
        </div>
        <div>
            <label for="password">Passwort: </label>
            <input type="password" name="password" id="password" placeholder="Bitte das Passwort eingeben" value="<?= $_POST['password'] ?? '' ?>" required>
        </div>
        <div>
            <button type="submit">anmelden</button>
        </div>
        <?php if (isset($message)) : ?>
            <p>
                <?= $message ?>
            </p>
        <?php endif; ?>
    </form>
</body>

</html>