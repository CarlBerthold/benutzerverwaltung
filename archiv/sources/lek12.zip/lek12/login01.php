<?php

$userData = [
    [
        'loginname' => 'oliver.vogt@d-taube.de',
        'password' => 'ganzgeheim', // absolutes no-go - Passwörter dürfen nie nie nie in Klartext verfügbar sein
    ],
    [
        'loginname' => 'hans@wurst.de',
        'password' => 'Pa$$w0rd', // absolutes no-go - Passwörter dürfen nie nie nie in Klartext verfügbar sein
    ],
];

// var_dump($_POST);
// var_dump($_SERVER);

// if($_SERVER["REQUEST_METHOD"] === 'POST') {
// if(!empty($_POST)) {
if($_POST) {
    foreach($userData as $index => $user) {
        if($_POST['loginname'] === $user['loginname'] && $_POST['password'] === $user['password']) {
            // hier Weiterleitung auf die gewünschte Seite
            echo "Hallo {$user['loginname']} ! Du bist eingelogged";
            exit;
        } 
    }
    $message = 'Die Kombination Benutzername und Kennwort stimmen nicht überein!';
}

?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <form action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
        <div>
            <label for="loginname">Loginname: </label>
            <!-- <input type="text" name="loginname" id="loginname" placeholder="Bitte den Loginnamen eingeben" value="<?= (isset($_POST['loginname'])) ? $_POST['loginname'] : '' ?>" required> -->
            <input
                type="text"
                name="loginname"
                id="loginname"
                placeholder="Bitte den Loginnamen eingeben"
                value="<?= $_POST['loginname'] ?? '' ?>"
                required
            >
        </div>
        <div>
            <label for="password">Passwort: </label>
            <input type="password" name="password" id="password" placeholder="Bitte das Passwort eingeben" value="<?= $_POST['password'] ?? '' ?>" required>
        </div>
        <div>
            <button type="submit">anmelden</button>
        </div>
        <?php if(isset($message)) : ?>
        <p>
            <?= $message ?>
        </p>
        <?php endif; ?>
    </form>
</body>
</html>