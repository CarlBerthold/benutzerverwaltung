<?php

# Einlesen der csv-Datei direkt als array (aus dem Verzeichnis /source)

$lines = file(__DIR__ . '/source/users.csv', FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES);

## erste Zeile mit den Spaltenbezeichnern löschen

unset($lines[0]);

$users = [];

foreach ($lines as $index => $user) {
    if($index > 0) {
        $users[] = explode(';', $user);
    }
}

## keys hinzufügen
### Array mit den Spalten gem. Notationsregeln für PHP

$keyArray = [
    'id',
    'firstname',
    'lastname',
    'email',
    'password',
    'role',
    'created_at', // das wäre eher MySQL ist aber auch in PHP erlaubt
    'updated_at',
];

## Arrays zusammenführen ($keyArray und jeweils die innere Dimension von $users)

foreach ($users as &$user) {
    # Datentyp von id in int umwandeln
    $user[0] = (int)$user[0];
    $user = array_combine($keyArray, $user);
}

var_export($users);
