<?php

# Einlesen 'users.data'

$users1 = unserialize(file_get_contents(__DIR__ . '/inc/users.data'));

# Einlesen 'users.json'

$users2 = json_decode(file_get_contents(__DIR__ . '/inc/users.json'), TRUE);

## Ausgabe

var_dump($users1, $users2);

## Vergleich

var_dump($users1 === $users2);