<?php

require_once 'inc/data.inc.php';

$users = fetchData();

// User über den Index der äußeren Dimension 
// $user = $users[0];

// eine User anhand seiner Id heraussuchen

$id = 99;

$idList = array_column($users, 'id');
$user = in_array($id, $idList) ? $users[array_search($id, $idList)] : exit("kein User mit der Id = $id gefunden!"); // die() entspricht exit - gibt eine Meldung aus und beendet das aktuelle Skript


?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Benutzerdaten bearbeiten</title>
    <style>
        #reg-data {
            display: grid;
            grid-template-columns: max-content 15vw;
            column-gap: .5em;
            row-gap: .3em;
        }
        #reg-data div {
            display: grid;
            grid-column: 1 / 3;
            grid-template-columns: subgrid;
        }
        .readonly {
            color: gray;
            background-color: lightcoral;
        }
    </style>
</head>
<body>
    <h1>Benutzerdaten bearbeiten</h1>
    <form action="#" method="post">
        <fieldset id="reg-data">
            <legend>Benutzerdaten</legend>
            <div>
                <label for="id">Benutzer-Id: </label>
                <input type="text" id="id" readonly class="readonly" value="<?= $user['id'] ?>">
            </div>
            <div>
                <label for="firstname">Vorname: </label>
                <input type="text" name="firstname" id="firstname" required value="<?= $user['firstname'] ?>">
            </div>
            <div>
                <label for="lastname">Nachname: </label>
                <input type="text" name="lastname" id="lastname" required value="<?= $user['lastname'] ?>">
            </div>
            <div>
                <label for="email">E-Mail: </label>
                <input type="email" name="email" id="email" required value="<?= $user['email'] ?>">
            </div>
            <div>
                <label for="password">Passwort: </label>
                <input type="password" name="password" id="password" required value="<?= $user['password'] ?>">
            </div>
            <div>
                <label for="created_at">registriert seit: </label>
                <input type="text" id="created_at" readonly class="readonly" value="<?= $user['created_at'] ?>">
            </div>
            <div>
                <label for="updated_at">geändert am: </label>
                <input type="text" name="updated_at" id="updated_at" readonly class="readonly" value="<?= $user['updated_at'] ?>">
            </div>
        </fieldset>
        <fieldset>
            <legend>Aktion</legend>
            <div>
                <button type="submit">ändern</button>
                <button type="reset">zurücksetzen</button>
            </div>
        </fieldset>
    </form>
</body>
</html>