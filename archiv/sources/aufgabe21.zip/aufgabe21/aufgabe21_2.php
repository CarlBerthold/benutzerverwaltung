<?php

require_once __DIR__ . '/inc/database.inc.php';
require_once __DIR__ . '/inc/database_functions.inc.php';

# Datenbankverbindung herstellen

$db = connectDB();

## a.) CRUD - Read - einen Datensatz aus der Tabelle auslesen

// Testen - ggf. vorab die Datenbanktabelle neu importieren - sql-Script /source/users.sql

$user = find(1, $db);
var_dump($user);

$user = find(99, $db);
var_dump($user);

## b.) CRUD - Create - einen neuen Datensatz erstellen

// Testen - ggf. vorab die Datenbanktabelle neu importieren - sql-Script /source/users.sql

$user = [
    'firstname' => "Erika",
    'lastname' => "Mustermann",
    'email' => "erika@example.com",
    'password' => "wiemax", // niemals in Klartext in der Datenbank speichern!
    'role' => "user",
    'created_at' => date('Y-m-d H:i:s'),
    'updated_at' => date('Y-m-d H:i:s'),
];

if (insert($user, $db)) {
    echo 'Datensatz erfolgreich erstellt', PHP_EOL;
} else {
    echo 'Datensatz konnte nicht erstellt werden', PHP_EOL;
};

## c.) CRUD - Update - Ändern eines Datensatzes

// Testen - ggf. vorab die Datenbanktabelle neu importieren - sql-Script /source/users.sql

$changes = [
    'id' => (int)$db->lastInsertId(), // hier kann auch ein beliebiger integer Wert für einen bestehenden Datensatz angegeben werden
    'lastname' => 'Gabler',
    'password' => 'schluss', // niemals in Klartext in der Datenbank speichern
    'updated_at' => date('Y-m-d H:i:s'),
];

if (update($changes, $db)) {
    echo 'Datensatz erfolgreich aktualisiert', PHP_EOL;
} else {
    echo 'Datensatz konnte nicht geändert werden', PHP_EOL;
};

## d.) CRUD - Delete - Löschen eines Datensatzes

// Testen - ggf. vorab die Datenbanktabelle neu importieren - sql-Script /source/users.sql

$id = 3; // willkürlich

if (delete($id, $db)) {
    echo 'Datensatz erfolgreich gelöscht', PHP_EOL;
} else {
    echo 'Datensatz konnte nicht gelöscht werden', PHP_EOL;
};


## e.) CRUDL - List - alle Datensätze auslesen

// Testen - ggf. vorab die Datenbanktabelle neu importieren - sql-Script /source/users.sql

$users = findAll($db);

if ($users) {
    var_dump($users);
} else {
    echo 'keine Datensätze gefunden!', PHP_EOL;
}

## Fehlerhandling testen

// Testen - ggf. vorab die Datenbanktabelle neu importieren - sql-Script /source/users.sql

$user = [
    'firstname' => "Monika", 
    'lastname' => "Mustermann",
    // 'email' => "erika@example.com", # email ist Pflichfeld
    'password' => "durchschnitt", // niemals in Klartext in der Datenbank speichern!
    'role' => "user",
    'created_at' => date('Y-m-d H:i:s'),
    'updated_at' => date('Y-m-d H:i:s'),
];

var_dump(insert($user, $db));