<?php

# Änderungen: $userData aus Datei data.inc.php laden
# der Key 'loginname' muss durch 'email' ersetzt werden - in der Datenstruktur ist email als Anmeldename vorgesehen

require_once __DIR__ . '/inc/data.inc.php';


# Session starten
session_start();

/* $userData = [
    [
        'name' => 'Oli',
        'loginname' => 'oliver.vogt@d-taube.de',
        'password' => 'ganzgeheim', // absolutes no-go - Passwörter dürfen nie nie nie in Klartext verfügbar sein
    ],
    [
        'name' => 'Hans',
        'loginname' => 'hans@wurst.de',
        'password' => 'Pa$$w0rd', // absolutes no-go - Passwörter dürfen nie nie nie in Klartext verfügbar sein
    ],
]; */

$userData = fetchData();

// $loginNames = array_column($userData, 'password', 'loginname');
# notwendige Anpassung - unsere Keys müssen jetzt die E-Mailadressen sein
$loginNames = array_column($userData, 'password', 'email');

if ($_POST) {
    if (array_key_exists($_POST['email'], $loginNames) && $_POST['password'] === $loginNames[$_POST['email']]) {
        $_SESSION['loggedin'] = TRUE;
        # Benutzernamen auslesen - z. Z. aufwändiger, das liegt an unserer Vorgehensweise und auch der Datenstruktur

        $_SESSION['name'] = array_reduce($userData, fn ($carry, $user) => ($user['email'] === $_POST['email']) ? $user['name'] : $carry);
        // aus Sicherheitsgründen neue Session-Id vergeben
        session_regenerate_id();
        header('Location: loggedin.php', TRUE, 307);
        exit;
    }

    $message = 'Die Kombination Benutzername und Kennwort stimmen nicht überein!';
}

?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>

<body>
    <form action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
        <div>
            <label for="loginname">E-Mail: </label>
            <input type="email" name="email" id="email" placeholder="Bitte die E-Mail-Adresse eingeben" value="<?= $_POST['email'] ?? '' ?>" required>
        </div>
        <div>
            <label for="password">Passwort: </label>
            <input type="password" name="password" id="password" placeholder="Bitte das Passwort eingeben" value="<?= $_POST['password'] ?? '' ?>" required>
        </div>
        <div>
            <button type="submit">anmelden</button>
        </div>
        <?php if (isset($message)) : ?>
            <p>
                <?= $message ?>
            </p>
        <?php endif; ?>
    </form>
</body>

</html>