<?php

# aus Aufgabe 11d `aufgabe11d.php`

## Funktionendefinitionen bzw. Funktionsdefinitionen laden

/* $users = [ // ausgelagert
    [
      'id' => 1,
      'firstname' => 'Oli',
      'lastname' => 'Vogt',
      'email' => 'oliver.vogt@d-taube.de',
      'password' => 'ganzgeheim',
      'role' => 'admin',
      'created_at' => '2023-01-15 08:30:00',
      'updated_at' => '2023-02-20 10:45:00',
    ],
    [
      'id' => 2,
      'firstname' => 'Oli',
      'lastname' => 'Vogt',
      'email' => 'oliver.vogt@ovmme.de',
      'password' => 'ganzgeheim',
      'role' => 'user',
      'created_at' => '2023-02-10 11:20:00',
      'updated_at' => '2023-03-05 09:15:00',
    ],
    [
      'id' => 3,
      'firstname' => 'Max',
      'lastname' => 'Mustermann',
      'email' => 'max@example.com',
      'password' => 'password',
      'role' => 'admin',
      'created_at' => '2023-01-15 08:30:00',
      'updated_at' => '2023-02-20 10:45:00',
    ],
    [
      'id' => 4,
      'firstname' => 'Anna',
      'lastname' => 'Schmidt',
      'email' => 'anna@example.com',
      'password' => 'pass123',
      'role' => 'user',
      'created_at' => '2023-02-10 11:20:00',
      'updated_at' => '2023-03-05 09:15:00',
    ],
    [
      'id' => 5,
      'firstname' => 'Peter',
      'lastname' => 'Müller',
      'email' => 'peter@example.com',
      'password' => 'p@ssw0rd',
      'role' => 'user',
      'created_at' => '2023-03-20 14:50:00',
      'updated_at' => '2023-04-18 12:30:00',
    ],
    [
      'id' => 6,
      'firstname' => 'Julia',
      'lastname' => 'Wagner',
      'email' => 'julia@example.com',
      'password' => 'secure12',
      'role' => 'inactive',
      'created_at' => '2023-04-05 09:10:00',
      'updated_at' => '2023-04-20 16:55:00',
    ],
    [
      'id' => 7,
      'firstname' => 'Thomas',
      'lastname' => 'Fischer',
      'email' => 'thomas@example.com',
      'password' => 'mypass',
      'role' => 'admin',
      'created_at' => '2023-05-08 10:25:00',
      'updated_at' => '2023-05-25 14:20:00',
    ],
    [
      'id' => 8,
      'firstname' => 'Sarah',
      'lastname' => 'Becker',
      'email' => 'sarah@example.com',
      'password' => '123456',
      'role' => 'user',
      'created_at' => '2023-06-12 13:40:00',
      'updated_at' => '2023-06-30 17:10:00',
    ],
    [
      'id' => 9,
      'firstname' => 'Michael',
      'lastname' => 'Schulz',
      'email' => 'michael@example.com',
      'password' => 'testpass',
      'role' => 'user',
      'created_at' => '2023-07-15 16:55:00',
      'updated_at' => '2023-07-28 10:05:00',
    ],
    [
      'id' => 10,
      'firstname' => 'Laura',
      'lastname' => 'Hoffmann',
      'email' => 'laura@example.com',
      'password' => 'secret',
      'role' => 'inactive',
      'created_at' => '2023-08-20 18:20:00',
      'updated_at' => '2023-09-05 11:25:00',
    ],
    [
      'id' => 11,
      'firstname' => 'Kevin',
      'lastname' => 'Richter',
      'email' => 'kevin@example.com',
      'password' => 'abc123',
      'role' => 'admin',
      'created_at' => '2023-09-25 20:45:00',
      'updated_at' => '2023-10-15 13:40:00',
    ],
    [
      'id' => 12,
      'firstname' => 'Maria',
      'lastname' => 'Lehmann',
      'email' => 'maria@example.com',
      'password' => 'passpass',
      'role' => 'user',
      'created_at' => '2023-10-30 22:00:00',
      'updated_at' => '2023-11-20 15:50:00',
    ],
]; */

require_once 'inc/data.inc.php';

## Programmierlogik

$users = fetchData();

// neues Array mit den deutschen Spaltenbezeichnern
$columnNamesDe = [
    'id' => 'Id',
    'firstname' => 'Vorname',
    'lastname' => 'Nachname',
    'email' => 'E-Mail',
    'password' => 'Passwort',
    'role' => 'Rolle',
    'created_at' => 'registriert seit',
    'updated_at' => 'geändert am',
];

## Ausgabe / der View
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Benutzerverwaltung</title>
</head>
<body>
    <h1>Benutzerverwaltung</h1>
    <table>
        <thead>
            <tr>
                <?php foreach($columnNamesDe as $columnName) { ?>
                    <th><?= $columnName ?></th>
                <?php } ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach($users as $user) { ?>
                <tr>
                    <?php foreach($user as $value) { ?>
                        <td><?= $value?></td>
                    <?php } ?>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>